const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    rollNumber: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email address']
    },
    department: {
        type: String,
        required: true,
        enum: ['Computer Science', 'Electrical', 'Mechanical', 'Civil', 'Software Engineering']
    },
    cgpa: {
        type: Number,
        required: true,
        min: 0.0,
        max: 4.0
    },
    enrollmentYear: {
        type: Number,
        required: true,
        min: 2000,
        max: new Date().getFullYear()
    },
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Student', studentSchema);