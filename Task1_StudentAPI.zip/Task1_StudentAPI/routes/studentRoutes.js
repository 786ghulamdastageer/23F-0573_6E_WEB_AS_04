const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

router.post('/students', studentController.createStudent);
router.get('/students', studentController.getAllStudents);
router.get('/students/search', studentController.searchStudents);
router.get('/students/:id', studentController.getStudentById);
router.put('/students/:id', studentController.updateStudent);
router.patch('/students/:id', studentController.partialUpdateStudent);
router.delete('/students/:id', studentController.deleteStudent);
router.patch('/students/:id/deactivate', studentController.deactivateStudent);

module.exports = router;