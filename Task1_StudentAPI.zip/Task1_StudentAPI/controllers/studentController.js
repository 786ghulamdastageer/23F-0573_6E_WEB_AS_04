const Student = require('../models/Student');

exports.createStudent = async (req, res) => {
    try {
        const { rollNumber, name, email, department, cgpa, enrollmentYear } = req.body;

        if (!rollNumber || !name || !email || !department || !cgpa || !enrollmentYear) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        const existingStudent = await Student.findOne({
            $or: [{ rollNumber }, { email }]
        });

        if (existingStudent) {
            return res.status(400).json({
                success: false,
                message: 'Student with same roll number or email already exists'
            });
        }

        const student = new Student({
            rollNumber,
            name,
            email,
            department,
            cgpa,
            enrollmentYear
        });

        await student.save();

        res.status(201).json({
            success: true,
            message: 'Student created successfully',
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getAllStudents = async (req, res) => {
    try {
        const { department, page = 1, limit = 10 } = req.query;
        
        let filter = {};
        if (department) {
            filter.department = department;
        }

        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const skip = (pageNum - 1) * limitNum;

        const students = await Student.find(filter)
            .skip(skip)
            .limit(limitNum)
            .sort({ createdAt: -1 });

        const total = await Student.countDocuments(filter);

        res.status(200).json({
            success: true,
            total,
            page: pageNum,
            limit: limitNum,
            totalPages: Math.ceil(total / limitNum),
            data: students
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getStudentById = async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.status(200).json({
            success: true,
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.searchStudents = async (req, res) => {
    try {
        const { name } = req.query;

        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Name query parameter is required'
            });
        }

        const students = await Student.find({
            name: { $regex: name, $options: 'i' }
        });

        res.status(200).json({
            success: true,
            count: students.length,
            data: students
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.updateStudent = async (req, res) => {
    try {
        const { rollNumber, name, email, department, cgpa, enrollmentYear } = req.body;

        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        if (email && email !== student.email) {
            const existingEmail = await Student.findOne({ email });
            if (existingEmail) {
                return res.status(400).json({
                    success: false,
                    message: 'Email already exists'
                });
            }
        }

        if (rollNumber && rollNumber !== student.rollNumber) {
            const existingRoll = await Student.findOne({ rollNumber });
            if (existingRoll) {
                return res.status(400).json({
                    success: false,
                    message: 'Roll number already exists'
                });
            }
        }

        student.rollNumber = rollNumber || student.rollNumber;
        student.name = name || student.name;
        student.email = email || student.email;
        student.department = department || student.department;
        student.cgpa = cgpa || student.cgpa;
        student.enrollmentYear = enrollmentYear || student.enrollmentYear;

        await student.save();

        res.status(200).json({
            success: true,
            message: 'Student updated successfully',
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.partialUpdateStudent = async (req, res) => {
    try {
        const updates = req.body;
        const allowedUpdates = ['rollNumber', 'name', 'email', 'department', 'cgpa', 'enrollmentYear'];
        const isValidOperation = Object.keys(updates).every(update => allowedUpdates.includes(update));

        if (!isValidOperation) {
            return res.status(400).json({
                success: false,
                message: 'Invalid update fields'
            });
        }

        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        if (updates.email && updates.email !== student.email) {
            const existingEmail = await Student.findOne({ email: updates.email });
            if (existingEmail) {
                return res.status(400).json({
                    success: false,
                    message: 'Email already exists'
                });
            }
        }

        if (updates.rollNumber && updates.rollNumber !== student.rollNumber) {
            const existingRoll = await Student.findOne({ rollNumber: updates.rollNumber });
            if (existingRoll) {
                return res.status(400).json({
                    success: false,
                    message: 'Roll number already exists'
                });
            }
        }

        Object.keys(updates).forEach(key => {
            student[key] = updates[key];
        });

        await student.save();

        res.status(200).json({
            success: true,
            message: 'Student updated successfully',
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.deleteStudent = async (req, res) => {
    try {
        const student = await Student.findByIdAndDelete(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Student deleted permanently'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.deactivateStudent = async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        student.isActive = false;
        await student.save();

        res.status(200).json({
            success: true,
            message: 'Student deactivated successfully',
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};