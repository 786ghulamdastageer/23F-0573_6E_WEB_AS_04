const Comment = require('../models/Comment');
const Post = require('../models/Post');
const User = require('../models/User');

exports.addComment = async (req, res) => {
    try {
        const { text, user } = req.body;
        const { postId } = req.params;

        if (!text || !user) {
            return res.status(400).json({
                success: false,
                message: 'Text and user are required'
            });
        }

        const postExists = await Post.findById(postId);
        if (!postExists) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const userExists = await User.findById(user);
        if (!userExists) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        const comment = new Comment({
            text,
            post: postId,
            user
        });

        await comment.save();

        const populatedComment = await Comment.findById(comment._id)
            .populate('user', 'username email');

        res.status(201).json({
            success: true,
            message: 'Comment added successfully',
            data: populatedComment
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getCommentsByPost = async (req, res) => {
    try {
        const { postId } = req.params;

        const postExists = await Post.findById(postId);
        if (!postExists) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const comments = await Comment.find({ post: postId })
            .populate('user', 'username email')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: comments.length,
            data: comments
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.deleteComment = async (req, res) => {
    try {
        const comment = await Comment.findByIdAndDelete(req.params.id);

        if (!comment) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Comment deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};