const Post = require('../models/Post');
const Comment = require('../models/Comment');

exports.createPost = async (req, res) => {
    try {
        const { title, content, author, tags } = req.body;

        if (!title || !content || !author) {
            return res.status(400).json({
                success: false,
                message: 'Title, content and author are required'
            });
        }

        const post = new Post({
            title,
            content,
            author,
            tags: tags || []
        });

        await post.save();

        const populatedPost = await Post.findById(post._id).populate('author', 'username email');

        res.status(201).json({
            success: true,
            message: 'Post created successfully',
            data: populatedPost
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getAllPosts = async (req, res) => {
    try {
        const posts = await Post.find()
            .populate('author', 'username email')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: posts.length,
            data: posts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getPostById = async (req, res) => {
    try {
        const post = await Post.findById(req.params.id)
            .populate('author', 'username email');

        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const comments = await Comment.find({ post: req.params.id })
            .populate('user', 'username email');

        res.status(200).json({
            success: true,
            post: post,
            comments: comments
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getPostsByTag = async (req, res) => {
    try {
        const { tag } = req.params;

        const posts = await Post.find({ tags: tag })
            .populate('author', 'username email');

        res.status(200).json({
            success: true,
            count: posts.length,
            data: posts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.updatePost = async (req, res) => {
    try {
        const { title, content, tags } = req.body;
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        if (title) post.title = title;
        if (content) post.content = content;
        if (tags) post.tags = tags;

        await post.save();

        const updatedPost = await Post.findById(post._id).populate('author', 'username email');

        res.status(200).json({
            success: true,
            message: 'Post updated successfully',
            data: updatedPost
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.deletePost = async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        await Comment.deleteMany({ post: req.params.id });
        await Post.findByIdAndDelete(req.params.id);

        res.status(200).json({
            success: true,
            message: 'Post and all associated comments deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};